# RuangWeb Studio — SEO Starter

Website statis multi-halaman untuk proyek demonstrasi SEO lokal.

## Sebelum publikasi (wajib)
1. Pilih satu platform: Vercel atau GitHub Pages.
2. Deploy folder ini sebagai project statis.
3. Setelah mendapat URL publik, ganti `https://GANTI-DOMAIN-SETELAH-DEPLOY/` di:
   - `index.html` (canonical, Open Graph URL, schema URL)
   - halaman HTML lain (canonical)
   - `robots.txt`
   - `sitemap.xml`
4. Pastikan URL final menggunakan HTTPS dan path sesuai konfigurasi hosting.
5. Buka seluruh halaman di desktop dan ponsel.
6. Submit `sitemap.xml` melalui Google Search Console.

## Penting
- RuangWeb Studio adalah brand demonstrasi, bukan bisnis aktif yang telah diverifikasi.
- Jangan menambahkan alamat, nomor telepon, testimoni, klien, foto proyek, atau klaim hasil yang tidak nyata.
- Jangan membuat Google Business Profile untuk entitas fiktif.
- Jangan menyatakan target Top 3 sebagai jaminan.
- Konten dan metadata perlu ditinjau lagi sebelum publikasi.

## Struktur
- `index.html` — homepage
- `jasa-website-umkm-semarang.html` — halaman topik utama
- `landing-page-bisnis.html` — halaman layanan/topik pendukung
- `website-katalog-produk.html` — halaman layanan/topik pendukung
- `panduan/memilih-website-umkm.html` — artikel panduan
- `assets/style.css` — styling responsif
- `assets/site.js` — navigasi mobile dan tahun footer
- `robots.txt`, `sitemap.xml`, `404.html`

## Catatan SEO teknis
Sitemap dan canonical masih memakai placeholder. Jangan deploy untuk tujuan indexing sebelum placeholder diganti dengan URL produksi yang benar.
